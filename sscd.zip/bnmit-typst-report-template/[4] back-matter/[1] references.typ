#let references() = {
  set text(size: 12pt, font: "Times New Roman", hyphenate: false)
  set page(
    margin: 1in,
    footer: none,
  )

  set align(center)
  [= REFERENCES]
  v(16pt)
  set align(left)

  let leading = 1.5em
  let leading = leading - 0.5em


  set par(
    justify: true,
    leading: leading,
  )

  hide[
    @aho2007compilers
    @levine1992lex
    @cooper2011engineering
    @appel1998modern
    @kernighan1988c
    @hopcroft2006introduction
    @louden2011compiler
    @grune2012modern
  ]
  bibliography("../citations.yaml", title: none)
}
