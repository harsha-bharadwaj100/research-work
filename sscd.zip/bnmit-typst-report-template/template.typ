#let conf(
  title: none,
  authors: (),
  year: none,
  department: none,
  doc,
) = {
  counter(page).update(1)
  let leading = 1.5em
  let leading = leading - 0.5em
  set par(justify: true, leading: leading)
  set text(
    font: "Times New Roman",
    size: 12pt,
  )
  set align(left)
  set block(spacing: leading)
  show figure.where(kind: image): set figure(
    supplement: [Fig.],
    numbering: (..nums) => {
      let chapter-num = counter(heading).get().first()
      let fig-num = nums.pos().first()
      str(chapter-num) + "." + str(fig-num)
    },
  )
  show figure.where(kind: table): set figure(
    supplement: [Table],
    numbering: (..nums) => {
      let chapter-num = counter(heading).get().first()
      let fig-num = nums.pos().first()
      str(chapter-num) + "." + str(fig-num)
    },
  )
  show figure.where(kind: table): it => {
    block[
      #it.caption
      #it.body
    ]
  }
  set heading(
    numbering: (..nums) => {
      let level = nums.pos().len()
      if (level == 1) {
        numbering("1", ..nums)
      } else {
        numbering("1.", ..nums)
      }
    },
  )
  show heading.where(level: 2): it => {
    v(leading)
    it
    v(leading / 2)
  }
  show heading.where(level: 1): it => {
    pagebreak(weak: true)
    counter(figure.where(kind: image)).update(0)
    counter(figure.where(kind: table)).update(0)

    block(width: 100%)[
      #set text(18pt, weight: "bold")
      #align(left)[CHAPTER #counter(heading).display()]
      #v(0.5em)
      #align(center)[#upper(it.body)]]
    v(leading)
  }
  show heading.where(level: 2): set text(size: 16pt)
  show heading.where(level: 3): set text(size: 14pt)
  let no_header_pages = state("no_hp")
  let no_footer_pages = state("no_fp")
  context {
    let chapters = query(
      heading.where(
        level: 1,
        outlined: true,
      ),
    )
    let nh_pages = ()
    let nf_pages = ()
    for chapter in chapters {
      let page = chapter.location().page()
      nh_pages.push(page)
    }
    no_header_pages.update(nh_pages)
    no_footer_pages.update(nf_pages)
  }
  set page(
    background: none,
    paper: "a4",
    margin: 1in,
    header: context {
      if not no_header_pages.get().contains(here().page()) {
        grid(
          gutter: 6pt,
          rows: 2,
          title,
          align: left,
          grid(
            rows: 2,
            gutter: 2pt,
            line(length: 100%, stroke: 0.5pt),
            line(length: 100%, stroke: 1pt),
          ),
        )
      }
    },
    footer: context {
      if not no_footer_pages.get().contains(here().page()) {
        grid(
          grid(
            rows: 2,
            gutter: 2pt,
            line(length: 100%, stroke: 0.5pt),
            line(length: 100%, stroke: 1pt),
          ),
          gutter: 6pt,
          rows: 2,
          grid(
            columns: 3,
            block(width: 100%, "Dept. of " + department.abbreviation + ", BNMIT"),
            block(width: 100%, align(center, counter(page).display())),
            block(width: 100%, align(right, year)),
          ),
          align: left,
        )
      }
    },
  )
  doc
}
