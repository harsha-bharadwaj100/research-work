// ====== Imports ======

#import "template.typ": conf
#import "[1] preamble/preamble.typ": preamble
#import "[2] front-matter/front-matter.typ": front_matter
#import "[4] back-matter/back-matter.typ": back_matter

// ====== Report Details ======

#let title = "Undeclared Variable Detector"
#let authors = (
  (
    name: "Adarsh Arun",
    usn: "1BG23CS006",
  ),
  (
    name: "Dhananjay S",
    usn: "1BG23CS040",
  ),
)
#let guide = (
  (
    name: "Prof. Priyanka Padki",
    designation: "Assistant Professor",
    department: (
      "CSE",
      "Computer Science and Engineering",
    ),
  ),
)

#let year = "2025-26"
#let semester = (
  6,
  "Sixth",
)
#let department = (
  name: "Computer Science and Engineering",
  abbreviation: "CSE",
  hod: "Dr. Krishnamurthy G N", // Placeholder for HOD
)
#let semester_section = "A"

#let subject = "System Software and Compiler Design"
#let subject_code = "23CSE161"

#let abstract = [
  The Lexical Analysis phase is the first step in a compiler where source code is converted into tokens. One critical task in this phase, often extended into semantic analysis, is ensuring that every identifier used in an expression has been previously declared. This project implements an "Undeclared Variable Detector" using C and Flex. The tool identifies C-style variable declarations and assignments, maintains a symbol table, and flags any variable usage that occurs before its declaration. It employs a two-pass strategy for each statement to correctly handle complex declarations like `int x = 5, y = x;`.
]

// ====== Template ======

#show: preamble.with(
  title: title,
  subject: subject,
  subject_code: subject_code,
  authors: authors,
  guide: guide,
  semester: semester,
  section: semester_section,
  department: department,
  year: year,
)

#show: front_matter.with(
  abstract_content: abstract,
  year: year,
  department: department,
)

// ====== Chapters ======

#{
  show: conf.with(
    title: title,
    year: year,
    department: department,
  )

  include "[3] chapters/[1] Problem Statement.typ"
  include "[3] chapters/[2] Objective.typ"
  include "[3] chapters/[3] Methodology.typ"
  include "[3] chapters/[4] Implementation.typ"
  include "[3] chapters/[5] Results.typ"
  include "[3] chapters/[6] Test Cases.typ"
  include "[3] chapters/[7] Conclusion.typ"
}

// ====== References ======

#show: back_matter()
