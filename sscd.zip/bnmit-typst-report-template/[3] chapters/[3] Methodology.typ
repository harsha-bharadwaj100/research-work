= Methodology / Approach

The implementation of the Undeclared Variable Detector follows a modular architecture, leveraging the strengths of **Flex** for low-level tokenization and **C** for high-level logic and symbol management.

== Tokenization (Flex Lexer)
The lexer (`undeclared_detector.l`) uses regular expressions to categorize input. It is designed to be "silent" on non-essential tokens like whitespace and comments. Key rules include:
- **Identifier Rule:** `{LETTER}({LETTER}|{DIGIT})*` matches C-style variable names.
- **Type Matching:** Specifically looks for `int`, `float`, `char`, etc., and returns a unique `TOK_TYPE` code.
- **Literal Skipping:** Dedicated rules for string literals (`"..."`) and comments (`//`, `/*...*/`) consume these characters without returning identifiers to the driver, preventing false errors.

== Symbol Table Architecture
The symbol table is implemented as a static array of `Symbol` structures. Each entry contains the identifier name and a `SymKind` enum to distinguish between variables and functions.
- `is_declared(name)`: Performs a linear search to check if a name already exists.
- `add_symbol(name)`: Inserts a new name if it is not already present and if it is not a reserved C keyword.

== The Two-Pass Evaluation Strategy
To handle C's flexible declaration syntax, the driver collects all tokens of a statement into a buffer until it encounters a semicolon (`;`). It then executes two passes:

1. **Pass 1 - Registration:** If the statement starts with a `TOK_TYPE`, the driver walks the token buffer. It looks for identifiers that are declarator names (e.g., those appearing after `int`, `*`, or `,`) and adds them to the symbol table.
2. **Pass 2 - Usage Verification:** The driver walks the buffer again. It skips tokens identified as declarator names in Pass 1. Any other `TOK_IDENT` is checked against the symbol table. If the identifier is missing, an error is triggered.

== Driver and I/O
The driver (`undeclared_detector.c`) supports three modes of operation:
- **File Mode:** Processes a `.c` or `.txt` file.
- **Expression Mode:** Processes a string passed via the `-e` flag (useful for testing).
- **Interactive Mode:** Reads from standard input until an EOF is reached.
The driver uses `yylineno` to track the exact line of each token, ensuring that errors are reported with helpful context.
