= Problem Statement

In compiler design, lexical analysis is the first phase of the compilation process, where the input source code is analyzed and divided into smaller units called tokens. These tokens represent meaningful elements such as keywords, identifiers, literals, operators, and symbols. Following this, semantic analysis ensures that these tokens are used according to the language's rules—most critically, the requirement that every variable must be declared before it is used.

Understanding this process can be challenging for beginners because lexical and semantic analysis are performed internally by the compiler and are not directly visible. As a result, it becomes difficult to clearly observe how a compiler tracks declarations and validates the usage of identifiers throughout the source code. To address this issue, the problem is to design and implement an **Undeclared Variable Detector** that takes source code as input from a file or expression and identifies any variable usage that occurs before its corresponding declaration.

The system should maintain a symbol table to record declarations, classify each token based on its type, and display detailed error messages for any identifier used without a prior declaration, including additional information such as line numbers.

*Sample Input:* `y = x + 5; int x;` \
*Expected Output:* `Error: x used before declaration.`

The visual representation of these errors helps in better understanding the working of declaration tracking and provides a practical insight into how compilers process source code. It allows users to clearly see how different elements of a program—such as variables, constants, and operators—are identified, categorized, and validated during the initial phases of compilation.

Additionally, the system should be able to handle multiple lines of input and different types of tokens, ensuring that the output accurately reflects the structure and declaration flow of the input program. This makes the tool useful not only for learning purposes but also for analyzing and debugging simple code segments to ensure they adhere to proper C-style declaration rules.
