= Sample Input and Output

The following section illustrates the execution of the Undeclared Variable Detector. The program can be executed via a shell command providing either a C source file or an inline expression using the `-e` flag.

== Successful Build and Execution
The detector is built by processing the Flex lexer and compiling it alongside the C driver using GCC. The following image shows the standard build command and the generated executable.

#figure(
  image("../outputs/build_successful(chapter 5).png", width: 90%),
  caption: [Terminal screenshot showing the build process and successful compilation.],
)

== Valid Input Analysis
When provided with syntactically correct C declarations, the detector confirms that all variables are declared before their usage.

#figure(
  image("../outputs/single_valid_testcase(chapter 5).png", width: 90%),
  caption: [Output for a valid program with no undeclared variables.],
)

== Error Detection
The detector identifies identifiers that appear in expressions without a prior declaration. It provides clear error messages with line numbers as shown below.

#figure(
  image("../outputs/single_invalide_test_case(chapter 5).png", width: 73%),
  caption: [Detection of a variable used before its declaration.],
)

== Edge Case Handling
This test ensures that the tool is robust against non-code elements. It demonstrates that identifiers within comments or string literals are correctly ignored.

#figure(
  image("../outputs/edge_test_case(chapter 5).png", width: 90%),
  caption: [Handling of edge cases like comments and string literals.],
)
