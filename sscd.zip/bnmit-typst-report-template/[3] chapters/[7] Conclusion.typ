= Conclusion

The Undeclared Variable Detector was successfully implemented using C and Flex, fulfilling the primary objective of detecting "Use before Declaration" errors in C-style source code. By bridging lexical analysis with a custom-built symbol table, the tool effectively mimics the early stages of a compiler's semantic analysis phase.

Key achievements of the project include:
- A robust lexical analyzer that filters out comments, strings, and numeric literals to ensure only relevant identifiers are processed.
- A dynamic and functional symbol table capable of tracking both variables and function names, preventing false positives on function calls.
- An innovative two-pass parsing strategy that correctly handles complex, multi-variable declarations with cross-references within a single statement (e.g., `int x = 5, y = x;`).
- Effective error deduplication and precise line-number tracking, significantly improving the feedback provided to the user.

Beyond meeting the basic requirements, the project successfully demonstrated how to handle various edge cases, such as skipping reserved keywords and managing trailing statements that lack semicolons. This tool provides a foundational understanding of the semantic analysis phase in a compiler, as discussed in foundational texts like the "Dragon Book" @aho2007compilers. It highlights the critical role of symbol tables in enforcing language rules before code generation begins.

Future enhancements could significantly broaden the tool's capabilities. These include introducing scope management to differentiate between local and global variables, implementing basic type-checking to ensure compatibility in expressions, and expanding the lexer to support more complex data structures like arrays and pointers.
