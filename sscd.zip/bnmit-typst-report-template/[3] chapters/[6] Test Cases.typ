= Test Cases

Validation is a critical step to ensure that the detector correctly distinguishes between valid C code and code containing undeclared variable usage. The following sections demonstrate the tool's performance across various scenarios.

== Valid Test Cases
Valid C code includes proper variable declarations, usage of variables after they have been declared, and complex declarations like `int x = 5, y = x;`. The detector correctly identifies these as valid and reports no errors.

#figure(
  image("../outputs/valid_test_cases_output(chapter 6).png", width: 90%),
  caption: [Output for valid C declarations.],
)

== Invalid Test Cases
Invalid test cases involve variables being used before their declaration, or variables that are never declared at all. The detector accurately flags these instances and provides the corresponding line numbers.

#figure(
  image("../outputs/invalid_test_cases_output(chapter 6).png", width: 85%),
  caption: [Error reporting for undeclared identifiers.],
)

== Edge Cases
Edge cases test the robustness of the detector against non-variable text that could be mistaken for identifiers. This includes string literals, block and line comments, and reserved keywords.The detector is designed to skip these tokens and avoid false positives.These edge cases validate that the detector handles minimal or irrelevant inputs without crashing or producing incorrect results. They confirm that the system correctly identifies the absence of meaningful identifiers and maintains stable behavior.

#figure(
  image("../outputs/edge.png", width: 85%),
  caption: [Detector Edge Case Validation.],
)
