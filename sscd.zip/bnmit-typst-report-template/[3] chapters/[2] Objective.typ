= Objective

The main objective of this project is to design and implement an **Undeclared Variable Detector** using C and Lex (Flex) that demonstrates the process of lexical analysis and early semantic verification in a clear and structured manner.

The specific objectives of this project are:
- To implement a lexical analyzer using Lex (Flex) and C, which can scan input source code and break it into meaningful tokens using pattern matching.
- To identify and classify tokens into various categories such as:
  - Keywords
  - Identifiers
  - Integer and Floating-point literals
  - String and Character literals
  - Operators
  - Symbols
- To accurately recognize different token patterns using regular expressions and ensure proper classification of each element in the input program.
- To identify and report variables used before their declaration in a clear and readable format, representing each error along with its line number using a structured sequence such as `Error (line 1): 'x' used before declaration`, thereby improving understanding of semantic rules.
- To handle multi-line input programs and ensure correct tracking of line numbers throughout the tokenization and detection process.
- To gain a deeper understanding of lexical and semantic analysis as the initial phases of a compiler and to bridge the gap between theoretical concepts and practical implementation.
- To develop a user-friendly system that helps in visualizing how source code is processed and validated internally by a compiler during the declaration tracking stage.


