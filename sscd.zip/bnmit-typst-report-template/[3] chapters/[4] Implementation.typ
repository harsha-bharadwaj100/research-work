= Program Implementation

The Undeclared Variable Detector is implemented across three core files. This modular design ensures that the lexical rules are isolated from the symbol table logic.

== Token Definitions (`undeclared_detector.h`)
The header file bridges the Lexer and the Driver by defining integer codes for different token types.

```c
#define TOK_TYPE    1   /* int / float / char ... */
#define TOK_IDENT   2   /* variable/function name */
#define TOK_ASSIGN  3   /* = */
#define TOK_SEMI    4   /* ; */
#define TOK_COMMA   5   /* , */
#define TOK_STAR    6   /* * (pointer) */
```

== Lexer Logic (`undeclared_detector.l`)
The Flex rules are prioritized such that keywords and types are matched before general identifiers.

```c
/* Rules for Keywords and Types */
"int"|"float"|"char"   { return TOK_TYPE; }
"if"|"else"|"while"    { return TOK_KEYWORD; }

/* Rules for Identifiers and Symbols */
{ID}                   { return TOK_IDENT; }
"="                    { return TOK_ASSIGN; }
";"                    { return TOK_SEMI; }
```

== Driver Logic (`undeclared_detector.c`)
The driver manages the symbol table and a token buffer to implement a two-pass strategy for each statement.

=== Symbol Table Structure
The symbol table stores all declared identifiers and their kinds (variables or functions) to allow for lookups during the usage check.

```c
typedef enum { SYM_VAR, SYM_FUNC } SymKind;

typedef struct {
    char    name[MAX_NAME_LEN];
    SymKind kind;
} Symbol;

static Symbol sym_table[MAX_SYMBOLS];
static int    sym_count = 0;
```

=== Token Buffer (`tbuf`)
To handle declarations like `int x = 5, y = x;`, the tool must register `x` before checking its usage in the same statement. All tokens between two semicolons are collected into a buffer.

```c
typedef struct {
    int  tok;              /* TOK_* code                  */
    char text[MAX_NAME_LEN];
    int  line;
} TokEntry;

static TokEntry tbuf[MAX_STMT_TOKENS];
static int      tbuf_len = 0;
```

=== Pass 1: Registering Declarations
In the first pass, the tool identifies declarations (statements starting with a type) and adds the identifiers to the symbol table.

```c
static void pass1_register_declarations(void) {
    int i = 0;
    while (i < tbuf_len && tbuf[i].tok == TOK_TYPE) i++;

    while (i < tbuf_len) {
        while (i < tbuf_len && tbuf[i].tok == TOK_STAR) i++;
        if (i >= tbuf_len) break;

        if (tbuf[i].tok == TOK_IDENT) {
            add_symbol(tbuf[i].text, SYM_VAR);
            i++;
        }

        /* Skip over the initialiser expression until the next comma or end */
        while (i < tbuf_len && tbuf[i].tok != TOK_COMMA) i++;
        if (i < tbuf_len && tbuf[i].tok == TOK_COMMA) i++;
    }
}
```

=== Pass 2: Checking Usage
The second pass iterates through the buffered tokens and checks if every identifier used has been previously declared.

```c
static void pass2_check_usage(int *errors) {
    int in_declaration = stmt_is_declaration();
    int expect_declarator = in_declaration ? 1 : 0;
    int past_assign = 0;

    for (int i = 0; i < tbuf_len; i++) {
        if (tbuf[i].tok == TOK_IDENT) {
            if (expect_declarator && !past_assign) {
                expect_declarator = 0;
                continue;
            }
            if (!is_declared(tbuf[i].text)) {
                printf("Error (line %d): '%s' used before declaration.\n",
                       tbuf[i].line, tbuf[i].text);
                (*errors)++;
            }
        }
        /* ... logic to update state (past_assign, etc.) ... */
    }
}
```

This implementation ensures that the tool is efficient, with $O(1)$ token matching and linear symbol table lookups suitable for small to medium-sized programs.
